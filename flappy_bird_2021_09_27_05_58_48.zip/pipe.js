function Pipe() {
  this.spacing = 175;
  this.top = random(height / 6, (3 / 4) * height);
  this.bottom = height - (this.top + this.spacing);
  this.x = width;
  this.w = 80;
  this.speed = 6;


  this.highlight = false;


  this.hits = function(bird) {
    if (bird.y < this.top || bird.y > height - this.bottom) {
      if (bird.x > this.x && bird.x < this.x + this.w) {
        this.highlight = true;
        return true;
      }
    }
    this.highlight = false;
    return false;
  };
  
  
    this.hits = function(bird2) {
    if (bird2.y < this.top || bird2.y > height - this.bottom) {
      if (bird2.x > this.x && bird2.x < this.x + this.w) {
        this.highlight = true;
        return true;
      }
    }
    this.highlight = false;
    return false;
  };


    this.hits = function(bird3) {
    if (bird3.y < this.top || bird3.y > height - this.bottom) {
      if (bird3.x > this.x && bird3.x < this.x + this.w) {
        this.highlight = true;
        return true;
      }
    }
    this.highlight = false;
    return false;
  };
  
  
  this.show = function() {
    fill(255);
    if (this.highlight) {
      fill(255, 255, 0);
    }
    rect(this.x, 0, this.w, this.top);
    rect(this.x, height - this.bottom, this.w, this.bottom);
  };


  this.update = function() {
    this.x -= this.speed;
  };


  this.offscreen = function() {
    if (this.x < -this.w) {
      return true;
    } else {
      return false;
    }
  };
}